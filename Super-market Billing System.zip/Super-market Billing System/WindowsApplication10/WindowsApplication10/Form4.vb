﻿Imports System
Imports System.Data.OleDb
Imports System.Data
Public Class Form4

    Private conn As OleDbConnection
    Private adpt As OleDbDataAdapter
    Private cmdbld As OleDbCommandBuilder
    Private myDs As DataSet
    Private sqlStr As String


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load





        Dim connStr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\SNEHRAJ\Desktop\Database6.accdb"
        conn = New OleDbConnection(connStr)

        conn.Open()
        myDs = New DataSet()
        sqlStr = "SELECT*FROM  Table1"
        adpt = New OleDbDataAdapter(sqlStr, conn)
        adpt.SelectCommand.CommandText = sqlStr
        cmdbld = New OleDbCommandBuilder(adpt)
        adpt.Fill(myDs, "Table1")


        DataGridView1.DataSource = myDs.Tables(0)




    End Sub

   



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try

            Dim newRow As DataRow = myDs.Tables("Table1").NewRow()
            newRow("ID") = TextBox2.Text
            newRow("customer") = TextBox1.Text
            newRow("product") = ComboBox1.Text
            newRow("price") = TextBox8.Text
            newRow("qty") = TextBox6.Text
            newRow("total") = TextBox5.Text
            myDs.Tables("Table1").Rows.Add(newRow)
            adpt.Update(myDs, "Table1")
            MessageBox.Show("Record successfully added")
        Catch ex As Exception

            MsgBox(ex.Message)

        End Try



    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged
      
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
          End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox9.Text = Val(TextBox9.Text) + Val(TextBox5.Text)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox8.Text = ""
        TextBox6.Text = ""
        TextBox5.Text = ""
        ComboBox1.Text = ""


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click



    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form5.Show()
        Me.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.Text = "Rice" Then
            TextBox8.Text = 50
        ElseIf ComboBox1.Text = "Wheat" Then
            TextBox8.Text = 30
        ElseIf ComboBox1.Text = "Jawar" Then
            TextBox8.Text = 25
        ElseIf ComboBox1.Text = "Suger" Then
            TextBox8.Text = 42
        ElseIf ComboBox1.Text = "Jaggery" Then
            TextBox8.Text = 38
        ElseIf ComboBox1.Text = "Soap" Then
            TextBox8.Text = 15
        ElseIf ComboBox1.Text = "Biscuit" Then
            TextBox8.Text = 18
        ElseIf ComboBox1.Text = "Shampoo" Then
            TextBox8.Text = 99
        ElseIf ComboBox1.Text = "Facewash" Then
            TextBox8.Text = 89
        ElseIf ComboBox1.Text = "Perfume" Then
            TextBox8.Text = 120
        ElseIf ComboBox1.Text = "Cold cream" Then
            TextBox8.Text = 100
        ElseIf ComboBox1.Text = "Sunscreen" Then
            TextBox8.Text = 109
        ElseIf ComboBox1.Text = "Toothpaste" Then
            TextBox8.Text = 75
        ElseIf ComboBox1.Text = "Mouthfreshner" Then
            TextBox8.Text = 78
        ElseIf ComboBox1.Text = "Milk" Then
            TextBox8.Text = 25
        ElseIf ComboBox1.Text = "Butter" Then
            TextBox8.Text = 49
        ElseIf ComboBox1.Text = "Buttermilk" Then
            TextBox8.Text = 30
        ElseIf ComboBox1.Text = "Chese" Then
            TextBox8.Text = 99
        ElseIf ComboBox1.Text = "Icecream" Then
            TextBox8.Text = 125
        ElseIf ComboBox1.Text = "Paneer" Then
            TextBox8.Text = 150
        ElseIf ComboBox1.Text = "Lassi" Then
            TextBox8.Text = 40
        ElseIf ComboBox1.Text = "Dark chocolate" Then
            TextBox8.Text = 100
        ElseIf ComboBox1.Text = "White chocolate" Then
            TextBox8.Text = 90
        ElseIf ComboBox1.Text = "Coffee" Then
            TextBox8.Text = 120
        ElseIf ComboBox1.Text = "Tea" Then
            TextBox8.Text = 80
        ElseIf ComboBox1.Text = "Chips" Then
            TextBox8.Text = 20
        ElseIf ComboBox1.Text = "Noodles" Then
            TextBox8.Text = 40
        ElseIf ComboBox1.Text = "Tomato sause" Then
            TextBox8.Text = 79
        ElseIf ComboBox1.Text = "Pasta" Then
            TextBox8.Text = 49
        ElseIf ComboBox1.Text = "Tamarind" Then
            TextBox8.Text = 20
        ElseIf ComboBox1.Text = "Tomato" Then
            TextBox8.Text = 15
        ElseIf ComboBox1.Text = "Potato" Then
            TextBox8.Text = 25
        ElseIf ComboBox1.Text = "Onion" Then
            TextBox8.Text = 25
        ElseIf ComboBox1.Text = "Garlic" Then
            TextBox8.Text = 35
        ElseIf ComboBox1.Text = "Chilli" Then
            TextBox8.Text = 10
        ElseIf ComboBox1.Text = "Coriender" Then
            TextBox8.Text = 15
        ElseIf ComboBox1.Text = "Lemmon" Then
            TextBox8.Text = 5
        ElseIf ComboBox1.Text = "Ginger" Then
            TextBox8.Text = 20
        ElseIf ComboBox1.Text = "Cobbage" Then
            TextBox8.Text = 25
        End If
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        TextBox5.Text = Val(TextBox6.Text) * Val(TextBox8.Text)

    End Sub
End Class