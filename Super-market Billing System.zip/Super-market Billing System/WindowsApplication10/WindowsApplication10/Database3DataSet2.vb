﻿Partial Class Database3DataSet2
    Partial Class SupermarketDataTable

        Private Sub SupermarketDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.ProductColumn.ColumnName) Then
                'Add user code here
            End If

        End Sub

    End Class

End Class

Namespace Database3DataSet2TableAdapters
    
    Partial Public Class SupermarketTableAdapter
    End Class
End Namespace
