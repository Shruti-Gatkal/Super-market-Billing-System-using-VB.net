﻿Imports System
Imports System.Data.OleDb
Imports System.Data
Public Class Form2
    Private conn1 As OleDbConnection
    Private adpt1 As OleDbDataAdapter
    Private cmdbld1 As OleDbCommandBuilder
    Private myDs1 As DataSet
    Private sqlStr1 As String

   


    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim connStr1 As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\SNEHRAJ\Documents\Database3.accdb"
        conn1 = New OleDbConnection(connStr1)
        conn1.Open()
        myDs1 = New DataSet()
        sqlStr1 = "SELECT*FROM  supermarket"
        adpt1 = New OleDbDataAdapter(sqlStr1, conn1)
        adpt1.SelectCommand.CommandText = sqlStr1
        cmdbld1 = New OleDbCommandBuilder(adpt1)
        adpt1.Fill(myDs1, "supermarket")
        DataGridView1.DataSource = myDs1.Tables(0)


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        DataGridView1.DataSource = myDs1.Tables(0)



        Try

            Dim newRow As DataRow = myDs1.Tables("supermarket").NewRow()
            newRow("ID") = TextBox4.Text
            newRow("Product") = TextBox3.Text

            newRow("Price") = TextBox1.Text
            newRow("Quantity") = TextBox2.Text
            myDs1.Tables("supermarket").Rows.Add(newRow)
            adpt1.Update(myDs1, "supermarket")
            MessageBox.Show("Record successfully added")
        Catch ex As Exception

            MsgBox(ex.Message)

        End Try


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form5.Show()
        Me.Close()
    End Sub
End Class






