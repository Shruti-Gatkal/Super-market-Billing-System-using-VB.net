﻿Public Class Form8
    Dim pass As String = "abc@123"
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If StrComp(pass, TextBox1.Text) = 0 Then
            Form5.Show()
            ErrorProvider1.Clear()
        Else
            ErrorProvider1.SetError(TextBox1, "you entered wrong password")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class